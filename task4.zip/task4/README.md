# Customer Task Management System

A full-stack application built with Angular frontend and Node.js/Express backend with MongoDB database for managing customers and their tasks.

## Features

- **Customer Management**: Create, read, update, and delete customers
- **Task Management**: Create, read, update, and delete tasks linked to customers
- **Task Status**: Mark tasks as completed or pending
- **Customer Filtering**: Filter tasks by customer
- **Responsive Design**: Modern UI with Bootstrap styling

## Database Schema

### Customers Collection
- `_id`: Unique identifier (ObjectId)
- `name`: Customer's full name (String, required)
- `occupation`: Customer's job/occupation (String, required)
- `phoneNumber`: Customer's phone number (String, required)
- `email`: Customer's email address (String, required, unique)
- `createdAt`: Creation timestamp
- `updatedAt`: Last update timestamp

### Tasks Collection
- `_id`: Unique identifier (ObjectId)
- `description`: Task description (String, required)
- `creationDate`: Task creation date (Date, default: now)
- `customerId`: Reference to customer (ObjectId, required)
- `isCompleted`: Task completion status (Boolean, default: false)
- `createdAt`: Creation timestamp
- `updatedAt`: Last update timestamp

## Prerequisites

- Node.js (v16 or higher)
- MongoDB (v4.4 or higher)
- Angular CLI (v17 or higher)

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd customer-task-management
   ```

2. **Install dependencies**
   ```bash
   npm run install-all
   ```

3. **Start MongoDB**
   Make sure MongoDB is running on your system:
   ```bash
   mongod
   ```

4. **Start the application**
   ```bash
   npm start
   ```

   This will start both the backend server (port 3000) and the Angular development server (port 4200).

## Manual Setup

If you prefer to set up the components separately:

### Backend Setup
```bash
cd server
npm install
npm start
```

### Frontend Setup
```bash
cd client
npm install
ng serve
```

## API Endpoints

### Customers
- `GET /api/customers` - Get all customers
- `GET /api/customers/:id` - Get customer by ID
- `POST /api/customers` - Create new customer
- `PUT /api/customers/:id` - Update customer
- `DELETE /api/customers/:id` - Delete customer

### Tasks
- `GET /api/tasks` - Get all tasks
- `GET /api/tasks/customer/:customerId` - Get tasks by customer
- `GET /api/tasks/:id` - Get task by ID
- `POST /api/tasks` - Create new task
- `PUT /api/tasks/:id` - Update task
- `DELETE /api/tasks/:id` - Delete task

## Usage

1. **Access the application**: Open your browser and go to `http://localhost:4200`

2. **Manage Customers**:
   - View all customers in the Customers tab
   - Add new customers with name, occupation, phone, and email
   - Edit existing customer information
   - Delete customers (this will also delete their associated tasks)

3. **Manage Tasks**:
   - View all tasks in the Tasks tab
   - Filter tasks by customer using the dropdown
   - Add new tasks with description and customer assignment
   - Mark tasks as completed or pending
   - Edit task details
   - Delete tasks

## Development

### Backend Development
```bash
cd server
npm run dev  # Uses nodemon for auto-restart
```

### Frontend Development
```bash
cd client
ng serve  # Auto-reloads on changes
```

## Project Structure

```
customer-task-management/
├── server/                 # Node.js backend
│   ├── models/            # MongoDB schemas
│   ├── routes/            # API routes
│   ├── config.js         # Configuration
│   └── server.js         # Main server file
├── client/                # Angular frontend
│   ├── src/app/
│   │   ├── components/    # Angular components
│   │   ├── models/        # TypeScript interfaces
│   │   └── services/      # HTTP services
│   └── ...
└── package.json          # Root package.json with scripts
```

## Technologies Used

- **Frontend**: Angular 17, TypeScript, Bootstrap 5
- **Backend**: Node.js, Express.js, MongoDB, Mongoose
- **Database**: MongoDB
- **Styling**: Bootstrap 5, Custom CSS

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test your changes
5. Submit a pull request

## License

This project is licensed under the MIT License.
