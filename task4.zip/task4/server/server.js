const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const config = require('./config');

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/api/getcustomers', require('./routes/customers'));
app.use('/api/getTasksList', require('./routes/tasks'));

app.get('/api/health', (req, res) => {
  res.json({ message: 'Server is running!' });
});

mongoose.connect(config.MONGODB_URI)
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('MongoDB connection error:', error);
  });

app.listen(config.PORT, () => {
  console.log(`Server is running on port ${config.PORT}`);
});
