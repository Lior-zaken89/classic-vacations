import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { CustomerListComponent } from './components/customer-list/customer-list.component';
import { CustomerFormComponent } from './components/customer-form/customer-form.component';
import { TaskListComponent } from './components/task-list/task-list.component';
import { TaskFormComponent } from './components/task-form/task-form.component';
import { FamilyDashboardComponent } from './components/family/family-dashboard/family-dashboard.component';
import { FamilyMemberFormComponent } from './components/family/family-member-form/family-member-form.component';
import { InteractionThreadComponent } from './components/family/interaction-thread/interaction-thread.component';
import { CustomerMainComponent } from './components/customer/customer-main/customer-main.component';
import { CustomerTaskFormComponent } from './components/customer/customer-task-form/customer-task-form.component';
import { ControllerComponent } from './components/controller/controller.component';
import { HomeComponent } from './components/home/home.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'customers', component: CustomerListComponent },
  { path: 'customers/new', component: CustomerFormComponent },
  { path: 'customers/edit/:id', component: CustomerFormComponent },
  { path: 'tasks', component: TaskListComponent },
  { path: 'tasks/new', component: TaskFormComponent },
  { path: 'tasks/edit/:id', component: TaskFormComponent }
  ,{ path: 'family', component: FamilyDashboardComponent }
  ,{ path: 'family/new', component: FamilyMemberFormComponent }
  ,{ path: 'family/edit/:id', component: FamilyMemberFormComponent }
  ,{ path: 'family/thread/:id', component: InteractionThreadComponent },
  { path: 'customer', component: CustomerMainComponent },
  { path: 'customer/add-task', component: CustomerTaskFormComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    CustomerListComponent,
    CustomerFormComponent,
    TaskListComponent,
    TaskFormComponent,
    FamilyDashboardComponent,
    FamilyMemberFormComponent,
    InteractionThreadComponent,
    CustomerMainComponent,
    CustomerTaskFormComponent,
    ControllerComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
