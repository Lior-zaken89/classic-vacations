export interface Customer {
  _id?: string;
  name: string;
  occupation: string;
  phoneNumber: string;
  email: string;
  createdAt?: string;
  updatedAt?: string;
}
