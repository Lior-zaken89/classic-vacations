export interface Task {
  _id?: string;
  description: string;
  creationDate: string;
  customerId: string;
  isCompleted: boolean;
  customer?: {
    _id: string;
    name: string;
    email: string;
  };
  createdAt?: string;
  updatedAt?: string;
}
