import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Task } from '../../models/task.model';
import { Customer } from '../../models/customer.model';
import { TaskService } from '../../services/task.service';
import { CustomerService } from '../../services/customer.service';

@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.component.html',
  styleUrls: ['./task-form.component.css']
})
export class TaskFormComponent implements OnInit {
  taskForm: FormGroup;
  isEdit = false;
  taskId: string | null = null;
  loading = false;
  customers: Customer[] = [];

  constructor(
    private fb: FormBuilder,
    private taskService: TaskService,
    private customerService: CustomerService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.taskForm = this.fb.group({
      description: ['', Validators.required],
      customerId: ['', Validators.required],
      isCompleted: [false]
    });
  }

  ngOnInit(): void {
    this.taskId = this.route.snapshot.paramMap.get('id');
    this.isEdit = !!this.taskId;

    this.loadCustomers();

    if (this.isEdit && this.taskId) {
      this.loadTask();
    }
  }

  loadCustomers(): void {
    this.customerService.getCustomers().subscribe({
      next: (customers) => {
        this.customers = customers;
      },
      error: (error) => {
        console.error('Error loading customers:', error);
      }
    });
  }

  loadTask(): void {
    this.loading = true;
    this.taskService.getTask(this.taskId!).subscribe({
      next: (task) => {
        this.taskForm.patchValue(task);
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading task:', error);
        this.loading = false;
      }
    });
  }

  onSubmit(): void {
    if (this.taskForm.valid) {
      this.loading = true;
      const taskData = this.taskForm.value;

      if (this.isEdit && this.taskId) {
        this.taskService.updateTask(this.taskId, taskData).subscribe({
          next: () => {
            this.router.navigate(['/tasks']);
          },
          error: (error) => {
            console.error('Error updating task:', error);
            this.loading = false;
          }
        });
      } else {
        this.taskService.createTask(taskData).subscribe({
          next: () => {
            this.router.navigate(['/tasks']);
          },
          error: (error) => {
            console.error('Error creating task:', error);
            this.loading = false;
          }
        });
      }
    }
  }

  cancel(): void {
    this.router.navigate(['/tasks']);
  }
}
