import { Component, Input, OnInit } from '@angular/core';
import { TaskService } from '../../services/task.service';
import { CustomerService } from '../../services/customer.service';

@Component({
  selector: 'app-controller',
  templateUrl: './controller.component.html',
  styleUrls: ['./controller.component.css']
})
export class ControllerComponent implements OnInit {
  @Input() pageType: 'main' | 'add' | 'customers' | 'tasks' = 'main';
  
  showController = false;
  currentLogic: string[] = [];
  serverRequests: string[] = [];
  lastRequest: any = null;

  constructor(
    private taskService: TaskService,
    private customerService: CustomerService
  ) {}

  ngOnInit(): void {
    this.updateController();
  }

  toggleController(): void {
    this.showController = !this.showController;
    if (this.showController) {
      this.updateController();
    }
  }

  updateController(): void {
    this.currentLogic = this.getCurrentLogic();
    this.serverRequests = this.getServerRequests();
  }

  getCurrentLogic(): string[] {
    switch (this.pageType) {
      case 'main':
        return [
          '1. Component loads (ngOnInit)',
          '2. Call loadTasks() method',
          '3. Set loading = true',
          '4. Make HTTP GET request to /api/getTasksList',
          '5. Display tasks in table with status badges',
          '6. Handle delete with confirmation dialog',
          '7. Refresh list after successful operations'
        ];
      case 'add':
        return [
          '1. Component loads (ngOnInit)',
          '2. Call loadCustomers() to populate dropdown',
          '3. User fills form with task description and customer',
          '4. Form validation checks required fields',
          '5. On submit: call createTask() method',
          '6. Make HTTP POST request to /api/getTasksList',
          '7. Navigate back to main page on success'
        ];
      case 'customers':
        return [
          '1. Component loads (ngOnInit)',
          '2. Call loadCustomers() method',
          '3. Make HTTP GET request to /api/getcustomers',
          '4. Display customers in table',
          '5. Handle CRUD operations (Create, Read, Update, Delete)',
          '6. Form validation for customer data'
        ];
      case 'tasks':
        return [
          '1. Component loads (ngOnInit)',
          '2. Call loadCustomers() and loadTasks()',
          '3. Make HTTP GET requests to both APIs',
          '4. Display tasks with customer filtering',
          '5. Handle task completion toggle',
          '6. Handle task updates (only if completed)',
          '7. Handle task deletion with confirmation'
        ];
      default:
        return [];
    }
  }

  getServerRequests(): string[] {
    switch (this.pageType) {
      case 'main':
        return [
          'GET /api/getTasksList - Load all tasks',
          'DELETE /api/getTasksList/:id - Delete specific task'
        ];
      case 'add':
        return [
          'GET /api/getcustomers - Load customers for dropdown',
          'POST /api/getTasksList - Create new task'
        ];
      case 'customers':
        return [
          'GET /api/getcustomers - Load all customers',
          'POST /api/getcustomers - Create new customer',
          'PUT /api/getcustomers/:id - Update customer',
          'DELETE /api/getcustomers/:id - Delete customer'
        ];
      case 'tasks':
        return [
          'GET /api/getcustomers - Load customers for filtering',
          'GET /api/getTasksList - Load all tasks',
          'GET /api/getTasksList/customer/:id - Filter tasks by customer',
          'PUT /api/getTasksList/:id - Update task (only if completed)',
          'PATCH /api/getTasksList/:id/complete - Mark task as completed',
          'DELETE /api/getTasksList/:id - Delete task'
        ];
      default:
        return [];
    }
  }

  simulateRequest(requestType: string): void {
    this.lastRequest = {
      type: requestType,
      timestamp: new Date().toISOString(),
      status: 'pending'
    };

    setTimeout(() => {
      this.lastRequest.status = 'completed';
      this.lastRequest.response = this.getMockResponse(requestType);
    }, 1000);
  }

  getMockResponse(requestType: string): any {
    switch (requestType) {
      case 'GET /api/getTasksList':
        return {
          data: [
            { _id: '1', description: 'Sample Task 1', isCompleted: false, customer: { name: 'John Doe' } },
            { _id: '2', description: 'Sample Task 2', isCompleted: true, customer: { name: 'Jane Smith' } }
          ],
          count: 2
        };
      case 'GET /api/getcustomers':
        return {
          data: [
            { _id: '1', name: 'John Doe', email: 'john@example.com' },
            { _id: '2', name: 'Jane Smith', email: 'jane@example.com' }
          ],
          count: 2
        };
      case 'POST /api/getTasksList':
        return {
          _id: '3',
          description: 'New Task',
          isCompleted: false,
          customer: { name: 'John Doe' }
        };
      case 'DELETE /api/getTasksList/:id':
        return { message: 'Task deleted successfully' };
      default:
        return { message: 'Request completed' };
    }
  }
}
