import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Task } from '../../../models/task.model';
import { TaskService } from '../../../services/task.service';

@Component({
  selector: 'app-customer-main',
  templateUrl: './customer-main.component.html',
  styleUrls: ['./customer-main.component.css']
})
export class CustomerMainComponent implements OnInit {
  tasks: Task[] = [];
  loading = false;

  constructor(
    private taskService: TaskService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.loadTasks();
  }

  loadTasks(): void {
    this.loading = true;
    this.taskService.getTasks().subscribe({
      next: (tasks) => {
        this.tasks = tasks;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading tasks:', error);
        this.loading = false;
      }
    });
  }

  addTask(): void {
    this.router.navigate(['/customer/add-task']);
  }

  getStatusClass(isCompleted: boolean): string {
    return isCompleted ? 'text-success' : 'text-warning';
  }

  getStatusText(isCompleted: boolean): string {
    return isCompleted ? 'Completed' : 'Pending';
  }

  deleteTask(task: Task): void {
    if (confirm(`Are you sure you want to delete this task: "${task.description}"?`)) {
      this.taskService.deleteTask(task._id!).subscribe({
        next: () => {
          this.loadTasks();
        },
        error: (error) => {
          console.error('Error deleting task:', error);
          alert('Error deleting task. Please try again.');
        }
      });
    }
  }
}
