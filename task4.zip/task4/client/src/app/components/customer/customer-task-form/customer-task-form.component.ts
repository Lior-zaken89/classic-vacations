import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Task } from '../../../models/task.model';
import { Customer } from '../../../models/customer.model';
import { TaskService } from '../../../services/task.service';
import { CustomerService } from '../../../services/customer.service';

@Component({
  selector: 'app-customer-task-form',
  templateUrl: './customer-task-form.component.html',
  styleUrls: ['./customer-task-form.component.css']
})
export class CustomerTaskFormComponent implements OnInit {
  taskForm: FormGroup;
  customers: Customer[] = [];
  loading = false;

  constructor(
    private fb: FormBuilder,
    private taskService: TaskService,
    private customerService: CustomerService,
    private router: Router
  ) {
    this.taskForm = this.fb.group({
      description: ['', Validators.required],
      customerId: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadCustomers();
  }

  loadCustomers(): void {
    this.customerService.getCustomers().subscribe({
      next: (customers) => {
        this.customers = customers;
      },
      error: (error) => {
        console.error('Error loading customers:', error);
      }
    });
  }

  onSubmit(): void {
    if (this.taskForm.valid) {
      this.loading = true;
      const taskData = this.taskForm.value;

      this.taskService.createTask(taskData).subscribe({
        next: () => {
          this.router.navigate(['/customer']);
        },
        error: (error) => {
          console.error('Error creating task:', error);
          this.loading = false;
        }
      });
    }
  }

  cancel(): void {
    this.router.navigate(['/customer']);
  }
}
