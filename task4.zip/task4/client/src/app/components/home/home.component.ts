import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Task } from '../../models/task.model';
import { Customer } from '../../models/customer.model';
import { TaskService } from '../../services/task.service';
import { CustomerService } from '../../services/customer.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  tasks: any[] = [];
  customers: any[] = [];
  loading = false;

  constructor(
    private taskService: TaskService,
    private customerService: CustomerService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.loading = true;
    
    this.customerService.getCustomers().subscribe({
      next: (customers) => {
        this.customers = customers;
        this.loadTasks();
      },
      error: (error) => {
        console.error('Error loading customers:', error);
        this.loading = false;
      }
    });
  }

  loadTasks(): void {
    this.taskService.getTasks().subscribe({
      next: (tasks) => {
        this.tasks = tasks;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading tasks:', error);
        this.loading = false;
      }
    });
  }

  toggleTaskCompletion(task: any): void {
    const updatedTask = { ...task, isCompleted: !task.isCompleted };
    this.taskService.updateTask(task._id, updatedTask).subscribe({
      next: () => {
        task.isCompleted = !task.isCompleted;
      },
      error: (error) => {
        console.error('Error updating task:', error);
        alert('Failed to update task');
      }
    });
  }

  getCustomerName(customerId: string): string {
    const customer = this.customers.find(c => c._id === customerId);
    return customer ? customer.name : 'Unknown Customer';
  }

  navigateToCustomers(): void {
    this.router.navigate(['/customers']);
  }

  navigateToTasks(): void {
    this.router.navigate(['/tasks']);
  }
}
