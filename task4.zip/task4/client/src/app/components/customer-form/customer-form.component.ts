import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Customer } from '../../models/customer.model';
import { CustomerService } from '../../services/customer.service';

@Component({
  selector: 'app-customer-form',
  templateUrl: './customer-form.component.html',
  styleUrls: ['./customer-form.component.css']
})
export class CustomerFormComponent implements OnInit {
  customerForm: FormGroup;
  isEdit = false;
  customerId: string | null = null;
  loading = false;

  constructor(
    private fb: FormBuilder,
    private customerService: CustomerService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.customerForm = this.fb.group({
      name: ['', Validators.required],
      occupation: ['', Validators.required],
      phoneNumber: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });
  }

  ngOnInit(): void {
    this.customerId = this.route.snapshot.paramMap.get('id');
    this.isEdit = !!this.customerId;

    if (this.isEdit && this.customerId) {
      this.loadCustomer();
    }
  }

  loadCustomer(): void {
    this.loading = true;
    this.customerService.getCustomer(this.customerId!).subscribe({
      next: (customer) => {
        this.customerForm.patchValue(customer);
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading customer:', error);
        this.loading = false;
      }
    });
  }

  onSubmit(): void {
    if (this.customerForm.valid) {
      this.loading = true;
      const customerData = this.customerForm.value;

      if (this.isEdit && this.customerId) {
        this.customerService.updateCustomer(this.customerId, customerData).subscribe({
          next: () => {
            this.router.navigate(['/customers']);
          },
          error: (error) => {
            console.error('Error updating customer:', error);
            this.loading = false;
          }
        });
      } else {
        this.customerService.createCustomer(customerData).subscribe({
          next: () => {
            this.router.navigate(['/customers']);
          },
          error: (error) => {
            console.error('Error creating customer:', error);
            this.loading = false;
          }
        });
      }
    }
  }

  cancel(): void {
    this.router.navigate(['/customers']);
  }
}
