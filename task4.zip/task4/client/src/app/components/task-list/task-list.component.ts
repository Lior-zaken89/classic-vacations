import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Task } from '../../models/task.model';
import { Customer } from '../../models/customer.model';
import { TaskService } from '../../services/task.service';
import { CustomerService } from '../../services/customer.service';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {
  tasks: any[] = [];
  customers: any[] = [];
  loading = false;
  selectedCustomerId = '';
  errorMessage = '';

  constructor(
    private taskService: TaskService,
    private customerService: CustomerService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.loadCustomers();
    this.loadTasks();
  }

  loadCustomers(): void {
    this.customerService.getCustomers().subscribe({
      next: (customers) => {
        this.customers = customers;
        console.log('customers loaded:', customers);
      },
      error: (error) => {
        console.error('Error loading customers:', error);
        this.errorMessage = 'Failed to load customers';
      }
    });
  }

  loadTasks(): void {
    this.loading = true;
    this.taskService.getTasks().subscribe({
      next: (tasks) => {
        this.tasks = tasks;
        this.loading = false;
        console.log('tasks loaded:', tasks.length);
      },
      error: (error) => {
        console.error('Error loading tasks:', error);
        this.loading = false;
        this.errorMessage = 'Failed to load tasks';
      }
    });
  }

  filterByCustomer(): void {
    if (this.selectedCustomerId) {
      this.loading = true;
      this.taskService.getTasksByCustomer(this.selectedCustomerId).subscribe({
        next: (tasks) => {
          this.tasks = tasks;
          this.loading = false;
        },
        error: (error) => {
          console.error('Error loading tasks:', error);
          this.loading = false;
        }
      });
    } else {
      this.loadTasks();
    }
  }

  toggleTaskCompletion(task: any): void {
    const updatedTask = { ...task, isCompleted: !task.isCompleted };
    this.taskService.updateTask(task._id, updatedTask).subscribe({
      next: () => {
        task.isCompleted = !task.isCompleted;
        console.log('task updated');
      },
      error: (error) => {
        console.error('Error updating task:', error);
        alert('Failed to update task');
      }
    });
  }

  editTask(task: any): void {
    this.router.navigate(['/tasks/edit', task._id]);
  }

  deleteTask(task: any): void {
    if (confirm(`Are you sure you want to delete this task?`)) {
      this.taskService.deleteTask(task._id).subscribe({
        next: () => {
          this.loadTasks();
          console.log('task deleted');
        },
        error: (error) => {
          console.error('Error deleting task:', error);
          alert('Failed to delete task');
        }
      });
    }
  }

  addTask(): void {
    this.router.navigate(['/tasks/new']);
  }

  getCustomerName(customerId: string): string {
    const customer = this.customers.find(c => c._id === customerId);
    if (customer) {
      return customer.name;
    } else {
      return 'Unknown Customer';
    }
  }
}
